﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD
{
    class Transfer
    {
       public int Transfer_ID;
       public int TypeOfTransfer;
       public decimal Transfer_Money;
    }
}
