﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD.Class
{
     class Credit
    {
        public int Cr_ID;
        public decimal Cr_Money;
        public int Cr_Time;
        public int Cr_percent;
        public decimal Cr_Pay;
    }
}
