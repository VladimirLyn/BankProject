﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD.Class
{
    public class Bank_Card
    {
        public long Card_Number;
        public string Card_Name;
        public int Card_Pin_Code;
        public int Card_serial_number;
       
    }
    public class Bank_CardAvailabilityearlier
    {
        public int Int_Availabilityearlier;
        public bool Bool_Availabilityearlier;
    }
}

