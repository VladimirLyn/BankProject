﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD.Class
{
     class Contribution
    {
       public long Cont_ID;
       public decimal Cont_Money;
       public int Cont_Time;
       public int  Cont_percent;
       public decimal Cont_pay;
    }
}
