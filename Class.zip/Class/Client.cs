﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD
{
    class Client
    {
        public long Client_ID;
        public string Client_Name;
        public int Client_Age;
        public int Int_Client_Gender;   // от введённого числа зависит гендер
        public string Str_Client_Gender;
    }
}
