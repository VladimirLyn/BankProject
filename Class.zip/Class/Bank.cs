﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD
{
     class Bank
    {
        public string Bank_Name = "Тинькофф";
        public decimal Bank_Money = 1000000000;
        public decimal Bank_Percent;
    }
}
