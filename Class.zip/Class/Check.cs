﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjecktCMD
{
    class Check
    {
        public long Check_ID;
        public decimal Check_Money;
        public int Int_Register;
        public bool Bool_Register;
    }
}
